#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "abonado.h"
#include "llamada.h"
#include "informes.h"


int abonadoConMasReclamos(Llamada* arrayLlamadas,int limiteLlamadas,Abonado* arrayAbonados, int limiteAbonado)
{


    return 0;
}


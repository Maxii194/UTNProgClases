#ifndef PRODUCTO_H_INCLUDED
#define PRODUCTO_H_INCLUDED

typedef struct{
    char nombreProducto[50];
    int precio;
    int stock;
    int idProducto;
    int idUsuario;
    int cantidadVendida;
}Producto;

void prod_ini(Producto *arrayProductos,int sizeArray);
void prod_publicarProducto(Producto* arrayProducto,int sizeArray);
void prod_modificarProducto(Producto* arrayProductos, int sizeArray,char* mensaje);
void prod_cancelarProducto();
void prod_comprarProducto();
void prod_listarProductos();

#endif // PRODUCTO_C_INCLUDED

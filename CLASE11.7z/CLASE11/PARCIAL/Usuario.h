#ifndef USUARIO_H_INCLUDED
#define USUARIO_H_INCLUDED

typedef struct{
    char nombreUsuario[50];
    char password[50];
    int idUsuario;
    int isEmpty;
}Usuario;

void user_ini(Usuario* arrayUsuarios, int sizeArray);
void user_alta(Usuario* arrayUsuarios,int sizeArray);
int user_modificarUser(Usuario* arrayUsuarios,int sizeArray, char* mensaje);
void user_bajaUser(Usuario* arrayUsuarios,int sizeArray,char* mensaje);
void user_mostrar(Usuario* arrayUsuarios, int sizeArray);


#endif // USUARIO_H_INCLUDED

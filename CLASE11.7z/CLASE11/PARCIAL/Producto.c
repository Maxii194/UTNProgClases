#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcs.h"
#include "Usuario.h"
#include "Producto.h"

void prod_ini(Producto* arrayProductos, int sizeArray){

    int i;
    for(i=0;i<=sizeArray;i++){

        strcpy(arrayProductos[i].nombreProducto,"");
        arrayProductos[i].precio = -1;
        arrayProductos[i].stock = 0;
        arrayProductos[i].idProducto = -1;
        arrayProductos[i].idUsuario = -1;
        arrayProductos[i].cantidadVendida = -1;
    }

}

void prod_publicarProducto(Producto* arrayProductos, int sizeArray){


    int i;
    char nombreProducto[50];
    int precio[3];
    int stock[1000];
    int idProducto[1000];
    int idUsuario[100];

    for(i=0;i<sizeArray;i++){

        if(arrayProductos[i].idProducto == 0){

            getInt("\nID: ","\nID invalido\n",10,1,100,idUsuario);
            arrayProductos[i].idUsuario = *idUsuario;
            getString(nombreProducto,"\nID Producto: ","El largo debe ser entre 4 y 50\n", 4, 50);
            strcpy(arrayProductos[i].nombreProducto,nombreProducto);
            getInt("\nPrecio: ","\nprecio invalido\n",10,1,10000,precio);
            arrayProductos[i].precio = *precio;
            getInt("\nStock: ","\ncantidad invalida\n",10,1,1000,stock);
            arrayProductos[i].stock = *stock;
            getInt("\nID: ","\nID invalido\n",10,1,100,idProducto);
            arrayProductos[i].idProducto = *idProducto;
        }
    }
}

int prod_modificarProducto(Producto* arrayProductos, int sizeArray,char* mensaje){

    int i,j,id;
    char nombreProducto[50];
    int precio[3];
    int stock[1000];

    printf("\n%s", mensaje);
    scanf("%d",&id);

    for(j=0;j<=sizeArray;j++){

        if(arrayUsuarios[j].idUsuario == id){

            printf("Usuario: %s", arrayUsuarios[j].nombreUsuario);
        }
    }

    for(i=0;i<=sizeArray;i++){

        if(arrayUsuarios[i].idUsuario == id){

            getString(nombreUsuario,"\nUsuario: ","El largo debe ser entre 4 y 50\n", 4, 50);
            strcpy(arrayUsuarios[i].nombreUsuario,nombreUsuario);
            getString(password,"\nPassword: ","El largo debe ser entre 4 y 50\n", 4, 50);
            strcpy(arrayUsuarios[i].password,password);
            getInt("\nID: ","\nID invalido\n",10,1,100,idUsuario);
            arrayUsuarios[i].idUsuario = *idUsuario;
            arrayUsuarios[i].isEmpty = 1;
        }
        else{

            printf("\nNo se encontro el usuario\n");
            return 1;
        }
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Usuario.h"
#include "funcs.h"
#include "Producto.h"
#define CantUser 3
#define CantProd 3

int main(void)
{
    Usuario arrayUsuarios[CantUser];
    Producto arrayProductos[CantProd];
    int continuar = 1;
    int id;
    int opcion;

    user_ini(arrayUsuarios,CantUser);
    user_alta(arrayUsuarios,1);
    //user_baja(arrayUsuarios,2,"Ingrese id del usuario a eliminar: ");
    user_modificarUser(arrayUsuarios,1,"Ingrese id del usuario a modificar: ");
    user_mostrar(arrayUsuarios,CantUser);



    /*do{
        menu();
        printf("\nOpcion: ");
        scanf("%d",&opcion);

        switch(opcion){

            case 1:

                emp_alta(arrayEmpleados,QTY);
                break;
            case 2:

                getInt("\nID: ","\nID invalido\n", 10, 2, 10, &id);
                emp_baja(arrayEmpleados,QTY,id);
                break;
            case 3:

                emp_mostrar(arrayEmpleados,QTY);
                break;
            case 4:

                continuar = opcion;
                break;
        }

        printf("\n");

    }while(continuar == 1);
*/
    return 0;
}

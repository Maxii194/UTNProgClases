#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcs.h"
#include "Usuario.h"

void user_ini(Usuario* arrayUsuarios, int sizeArray){

    int i;
    for(i=0;i<=sizeArray;i++){

        strcpy(arrayUsuarios[i].nombreUsuario,"");
        strcpy(arrayUsuarios[i].password,"");
        arrayUsuarios[i].idUsuario = -1;
        arrayUsuarios[i].isEmpty = 0;
    }

}

void user_alta(Usuario* arrayUsuarios,int sizeArray){

    int i;
    char nombreUsuario[50];
    char password[50];
    int idUsuario[10];

    for(i=0;i<sizeArray;i++){

        if(arrayUsuarios[i].isEmpty == 0){

            getString(nombreUsuario,"\nUsuario: ","El largo debe ser entre 4 y 50\n", 4, 50);
            strcpy(arrayUsuarios[i].nombreUsuario,nombreUsuario);
            getString(password,"\nPassword: ","El largo debe ser entre 4 y 50\n", 4, 50);
            strcpy(arrayUsuarios[i].password,password);
            getInt("\nID: ","\nID invalido\n",10,1,100,idUsuario);
            arrayUsuarios[i].idUsuario = *idUsuario;
            arrayUsuarios[i].isEmpty = 1;

        }
    }
}

void user_mostrar(Usuario* arrayUsuarios,int sizeArray){

    int i;

    for(i=0;i<=sizeArray;i++){

        printf("\nUsuario ID: %d",arrayUsuarios[i].idUsuario);
        printf("\n\tUsuario: %s", arrayUsuarios[i].nombreUsuario);
        printf("\n\tPassword: %s", arrayUsuarios[i].password);
        printf("\n");
    }

}

void user_baja(Usuario* arrayUsuarios,int sizeArray,char* mensaje){

    int i,id;
    printf("\n%s", mensaje);
    scanf("%d",&id);
    for(i=0;i<=sizeArray;i++){

        if(arrayUsuarios[i].idUsuario == id){

            strcpy(arrayUsuarios[i].nombreUsuario,"");
            strcpy(arrayUsuarios[i].password,"");
            arrayUsuarios[i].idUsuario = -1;
            arrayUsuarios[i].isEmpty = 0;
        }
    }
}

int user_modificarUser(Usuario* arrayUsuarios,int sizeArray,char* mensaje){

    int i,id;
    char nombreUsuario[50];
    char password[50];
    int idUsuario[10];
    printf("\n%s", mensaje);
    scanf("%d",&id);
    for(i=0;i<=sizeArray;i++){

        if(arrayUsuarios[i].idUsuario == id){

            getString(nombreUsuario,"\nUsuario: ","El largo debe ser entre 4 y 50\n", 4, 50);
            strcpy(arrayUsuarios[i].nombreUsuario,nombreUsuario);
            getString(password,"\nPassword: ","El largo debe ser entre 4 y 50\n", 4, 50);
            strcpy(arrayUsuarios[i].password,password);
            getInt("\nID: ","\nID invalido\n",10,1,100,idUsuario);
            arrayUsuarios[i].idUsuario = *idUsuario;
            arrayUsuarios[i].isEmpty = 1;
        }
        else{

            printf("\nNo se encontro el usuario\n");
            return 1;
        }
    }

    return 0;
}

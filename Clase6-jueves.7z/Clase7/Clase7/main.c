#include <stdio.h>
#include <stdlib.h>
#include "funcs.h"
#define MAX  5



int main()
{
    int arreglo[MAX]={4,3,1,6,8};

    OrdenarArray(arreglo,MAX,1);
    MostrarArray(arreglo,MAX);
    OrdenarArray(arreglo,MAX,0);
    MostrarArray(arreglo,MAX);

    return 0;
}

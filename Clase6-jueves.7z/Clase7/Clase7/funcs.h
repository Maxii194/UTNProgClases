int getInt(char* mensaje,char* mensajeError,int reIntentos,int minimo,int maximo,int* resultado);
int esEntero(char *str);
int OrdenarArray(int* arreglo,int cantidad, int orden);
int MostrarArray(int* arreglo, int cantidad);


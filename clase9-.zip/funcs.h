int getInt(char* mensaje,char* mensajeError,int reIntentos,int minimo,int maximo,int* resultado);
int esEntero(char *str);
int mostrarArrayInt(int * array,int cantidad);
int ordenarArrayInt(int * array,int cantidad,int orden);
int ordenarArrayIntInsertion(int * array,int cantidad,int orden);

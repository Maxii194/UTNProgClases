int getInt(char* mensaje,char* mensajeError,int reIntentos,int minimo,int maximo,int* resultado);
int esEntero(char *str);
int OrdenarArray(int* arreglo,int cantidad, int orden);
int MostrarArray(int* arreglo, int cantidad);
char getString(char* input,char message[],char eMessage[], int lowLimit, int hiLimit);
char getStringOpcion(char* input,char message[],char eMessage[], int opcion1, int opcion2);


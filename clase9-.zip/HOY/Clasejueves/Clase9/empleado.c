#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcs.h"
#include "empleado.h"

int menu(){
    printf(" 1) Alta de Empleado\n 2) Baja de Empleado\n 3) Mostrar Empleados\n 4) Terminar\n");
    return 0;
}

int emp_init(Empleado* arrayEmpleados,int sizeArray){

    int i;
    for(i=0;i<=sizeArray;i++){

        arrayEmpleados[i].nombre = " ";
        arrayEmpleados[i].apellido = " ";
        arrayEmpleados[i].idEmpleado = 00;
        arrayEmpleados[i].isEmpty = 0;
    }

    return 0;
}

int emp_alta(Empleado* arrayEmpleados,int sizeArray){

    int i;
    char nombre[50];
    char apellido[50];
    int idEmpleado[10];

    for(i=0;i<=sizeArray;i++){

        if(arrayEmpleados[i].isEmpty == 0){

            getString(nombre,"\nNombre: ","El largo debe ser entre 2 y 50\n", 2, 50);
            strcpy(arrayEmpleados[i].nombre,nombre);
            getString(apellido,"\nApellido: ","El largo debe ser entre 2 y 50\n", 2, 50);
            strcpy(arrayEmpleados[i].apellido,apellido);
            getInt("\nID: ","\nID invalido\n", 10, 1, sizeArray, idEmpleado);
            arrayEmpleados[i].idEmpleado = *idEmpleado;
            arrayEmpleados[i].isEmpty = 1;
            break;
        }

    }

    return 0;
}

int emp_baja(Empleado* arrayEmpleados,int sizeArray,int id){

    int i;
    for(i=0;i<=sizeArray;i++){

        if(arrayEmpleados[i].idEmpleado == id){

            arrayEmpleados[i].idEmpleado = 0;
        }
        break;
    }

    return 0;
}

int emp_mostrar(Empleado* arrayEmpleados,int sizeArray){

    int i;

    for(i=0;i<=sizeArray;i++){

        printf("\nEmpleado ID: %d",arrayEmpleados[i].idEmpleado);
        printf("\n\tNombre: %s", arrayEmpleados[i].nombre);
        printf("\n\tApellido: %s", arrayEmpleados[i].apellido);
        printf("\n");
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcs.h"
#include "empleado.h"
#define QTY 3

int main(void)
{
    Empleado arrayEmpleados[QTY];
    int continuar = 1;
    int id;
    int opcion;

    emp_init(arrayEmpleados,QTY);



    do{
        menu();
        printf("\nOpcion: ");
        scanf("%d",&opcion);

        switch(opcion){

            case 1:

                emp_alta(arrayEmpleados,QTY);
                break;
            case 2:

                getInt("\nID: ","\nID invalido\n", 10, 2, 10, &id);
                emp_baja(arrayEmpleados,QTY,id);
                break;
            case 3:

                emp_mostrar(arrayEmpleados,QTY);
                break;
            case 4:

                continuar = opcion;
                break;
        }

        printf("\n");

    }while(continuar == 1);

    return 0;
}
